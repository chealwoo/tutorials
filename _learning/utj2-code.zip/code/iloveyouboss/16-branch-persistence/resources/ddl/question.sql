create table question (
  id serial primary key,
  text text not null
);